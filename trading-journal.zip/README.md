# Trading Journal - Starter

This is a starter React + Vite + Tailwind project scaffold created for the user.

Quick steps:
1. Download and unzip.
2. In the project folder run:
   - `npm install`
   - `npm run dev`
3. Open the local dev URL shown in the terminal (usually http://localhost:5173).

If you prefer not to run locally, upload the files to a GitHub repo and import the repo into Vercel for automatic deployment.
