import React from 'react';
export default function Reports(){
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Reports</h2>
      <div className="p-4 bg-gray-800 rounded-2xl">Reports and export options will be here.</div>
    </div>
  );
}
