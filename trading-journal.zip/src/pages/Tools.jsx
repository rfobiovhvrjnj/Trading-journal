import React from 'react';
export default function Tools(){
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Tools</h2>
      <div className="p-4 bg-gray-800 rounded-2xl">Position sizing, risk calculators and utilities.</div>
    </div>
  );
}
