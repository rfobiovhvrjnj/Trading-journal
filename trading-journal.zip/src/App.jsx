import React from "react";
import { Routes, Route } from "react-router-dom";
import Sidebar from "./components/Sidebar";
import Dashboard from "./pages/Dashboard";
import Trades from "./pages/Trades";
import AISummarizer from "./pages/AISummarizer";
import Reports from "./pages/Reports";
import CalendarPage from "./pages/CalendarPage";
import Tools from "./pages/Tools";

export default function App(){
  return (
    <div className="min-h-screen flex">
      <Sidebar />
      <div className="flex-1 p-6">
        <Routes>
          <Route path="/" element={<Dashboard/>} />
          <Route path="/trades" element={<Trades/>} />
          <Route path="/ai" element={<AISummarizer/>} />
          <Route path="/reports" element={<Reports/>} />
          <Route path="/calendar" element={<CalendarPage/>} />
          <Route path="/tools" element={<Tools/>} />
        </Routes>
      </div>
    </div>
  );
}
