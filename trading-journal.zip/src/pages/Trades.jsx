import React from 'react';
export default function Trades(){
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Trades</h2>
      <div className="p-4 bg-gray-800 rounded-2xl">Trade entry form and history will be here.</div>
    </div>
  );
}
