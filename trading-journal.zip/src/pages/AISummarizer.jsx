import React, {useState} from 'react';

export default function AISummarizer(){
  const [period,setPeriod] = useState('last7');
  const [loading,setLoading] = useState(false);
  const [summary,setSummary] = useState(null);

  function analyze(){
    setLoading(true);
    setSummary(null);
    setTimeout(()=>{
      setSummary({
        short: "This week: +₹24,235.7 — strong breakout performance, avoid late entries.",
        detailed: [
          {title:'Win Rate', value:'72.7%'},
          {title:'Avg R:R', value:'1.35'},
          {title:'Top Strategy', value:'Breakout'},
          {title:'Common Mistakes', value:'Late exit, no volume confirmation'}
        ],
        advice: 'Keep SL tight on reversals. Consider reducing position size on low-volume days.'
      });
      setLoading(false);
    },800);
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold">AI Trading Analysis</h2>
      <div className="p-4 bg-card-dark rounded-2xl">
        <div className="flex items-center gap-4">
          <div>
            <label className="text-sm opacity-70">Analyse Period</label>
            <div className="flex gap-2 mt-2">
              <button onClick={()=>setPeriod('last7')} className={`px-3 py-1 rounded ${period==='last7' ? 'bg-accent' : 'bg-gray-900'}`}>Last 7 days</button>
              <button onClick={()=>setPeriod('last30')} className={`px-3 py-1 rounded ${period==='last30' ? 'bg-accent' : 'bg-gray-900'}`}>Last 30 days</button>
              <button onClick={()=>setPeriod('custom')} className={`px-3 py-1 rounded ${period==='custom' ? 'bg-accent' : 'bg-gray-900'}`}>Custom range</button>
            </div>
          </div>
          <div className="ml-auto">
            <button onClick={analyze} className="px-4 py-2 rounded-xl border">
              {loading ? 'Analysing...' : 'Generate AI Summary'}
            </button>
          </div>
        </div>
        <div className="mt-4 text-sm opacity-60">Analyze your last trading performance with AI insights.</div>
      </div>

      <div className="p-4 bg-card-dark rounded-2xl min-h-[140px]">
        {summary ? (
          <>
            <div className="text-lg font-semibold mb-2">Short summary</div>
            <div className="mb-3 opacity-80">{summary.short}</div>
            <div className="grid grid-cols-4 gap-3">
              {summary.detailed.map((d,i)=>(
                <div key={i} className="p-3 bg-gray-900 rounded">
                  <div className="text-xs opacity-60">{d.title}</div>
                  <div className="font-semibold">{d.value}</div>
                </div>
              ))}
            </div>
            <div className="mt-4">
              <h4 className="font-semibold">AI Advice</h4>
              <div className="opacity-80 mt-1">{summary.advice}</div>
            </div>
          </>
        ) : (
          <div className="opacity-50">No summary generated yet. Click <strong>Generate AI Summary</strong>.</div>
        )}
      </div>
    </div>
  );
}
