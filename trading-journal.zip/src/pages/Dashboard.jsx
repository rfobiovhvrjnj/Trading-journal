import React, { useState } from "react";

export default function Dashboard(){
  const [darkMode] = useState(true);
  const mockTrades = [
    {id:1,date:'2025-09-05',symbol:'RELIANCE',strategy:'Breakout',entry:2450,exit:2478,qty:10,pnl:280,outcome:'Win'},
    {id:2,date:'2025-09-04',symbol:'TCS',strategy:'Fibonacci Retracement',entry:3200,exit:3170,qty:5,pnl:-150,outcome:'Loss'}
  ];
  const totalProfit = mockTrades.reduce((s,t)=>s+(t.pnl||0),0);
  const winCount = mockTrades.filter(t=>t.outcome==='Win').length;
  const winRate = mockTrades.length ? Math.round((winCount/mockTrades.length)*100) : 0;

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <div className="text-sm opacity-60">Overview of your trading performance</div>
        </div>
      </header>

      <div className="grid grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-gray-800 shadow-md">
          <div className="text-xs opacity-70">Total Profit</div>
          <div className="text-2xl font-semibold">₹ {totalProfit.toFixed(2)}</div>
        </div>
        <div className="p-4 rounded-2xl bg-gray-800 shadow-md">
          <div className="text-xs opacity-70">Win Rate</div>
          <div className="text-2xl font-semibold">{winRate}%</div>
        </div>
        <div className="p-4 rounded-2xl bg-gray-800 shadow-md">
          <div className="text-xs opacity-70">Trades</div>
          <div className="text-2xl font-semibold">{mockTrades.length}</div>
        </div>
      </div>

      <div className="rounded-2xl p-4 bg-gray-800 shadow-md">
        <h3 className="font-semibold mb-3">Recent Trades</h3>
        <table className="min-w-full text-sm">
          <thead>
            <tr className="text-left opacity-60 text-xs">
              <th className="py-2">Date</th>
              <th>Symbol</th>
              <th>Strategy</th>
              <th>Entry</th>
              <th>Exit</th>
              <th>Qty</th>
              <th>PnL</th>
              <th>Outcome</th>
            </tr>
          </thead>
          <tbody>
            {mockTrades.map(t=>(
              <tr key={t.id} className="border-t border-gray-700">
                <td className="py-2 text-xs opacity-70">{t.date}</td>
                <td className="font-medium">{t.symbol}</td>
                <td className="opacity-80 text-sm">{t.strategy}</td>
                <td className="text-sm">{t.entry}</td>
                <td className="text-sm">{t.exit}</td>
                <td className="text-sm">{t.qty}</td>
                <td className={`text-sm ${t.pnl>=0?'text-emerald-400':'text-rose-400'}`}>₹ {t.pnl}</td>
                <td className="text-sm">{t.outcome}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
