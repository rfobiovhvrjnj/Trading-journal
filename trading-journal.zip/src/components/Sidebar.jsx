import React from "react";
import { NavLink } from "react-router-dom";
import { LayoutDashboard, BookOpen, FileBarChart, CalendarDays, Brain, Wrench } from "lucide-react";

const items = [
  {to:'/', label:'Dashboard', icon: LayoutDashboard},
  {to:'/trades', label:'Trades', icon: BookOpen},
  {to:'/reports', label:'Reports', icon: FileBarChart},
  {to:'/calendar', label:'Calendar', icon: CalendarDays},
  {to:'/ai', label:'AI Summarizer', icon: Brain},
  {to:'/tools', label:'Tools', icon: Wrench},
];

export default function Sidebar(){
  return (
    <aside className="w-64 bg-card-dark min-h-screen p-4 border-r border-gray-800">
      <div className="text-2xl font-bold mb-6 text-center text-accent">JIGAR's Journal</div>
      <nav className="flex flex-col gap-2 text-sm">
        {items.map(i => {
          const Icon = i.icon;
          return (
            <NavLink key={i.to} to={i.to}
              className={({isActive}) => 
                `flex items-center gap-3 p-3 rounded-xl transition-all
                 ${isActive 
                   ? 'bg-gray-800 text-accent shadow-[0_0_18px_rgba(59,130,246,0.45)]' 
                   : 'hover:bg-gray-900 hover:shadow-[0_0_12px_rgba(59,130,246,0.18)]'}`}>
              <div className="w-9 h-9 flex items-center justify-center rounded-lg">
                <Icon className="w-5 h-5" />
              </div>
              <span>{i.label}</span>
            </NavLink>
          );
        })}
      </nav>
    </aside>
  );
}
